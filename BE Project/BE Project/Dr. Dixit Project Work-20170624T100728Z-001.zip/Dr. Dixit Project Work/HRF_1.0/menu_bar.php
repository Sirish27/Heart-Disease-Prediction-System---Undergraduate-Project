<?php
include "head.php";
?>
<html>
    <head>
        <style>
            .menubar{
                width: 100%;
                height: 40px;
                background-color: #357ebd;
            }
            .menuButtons{
                margin-left: 10px;
                margin-top: 4px;
                width: 60px;
                height: 30px;
            }
        </style>
    </head>
    <body>
        <div class="menubar">
            <input type="button" class="menuButtons" value="Home"/>
            <input type="button" class="menuButtons" style="float: right; margin-right: 10px;" value="login"/>
        </div>
    </body>
