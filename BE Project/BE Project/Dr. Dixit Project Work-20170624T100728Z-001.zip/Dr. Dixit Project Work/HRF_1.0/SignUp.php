<?php
$con=mysql_connect("127.0.0.1","root","root");
mysql_select_db("test",$con);

$email=$_POST['emailID'];
$pass=$_POST['password'];
$fName=$_POST['fname'];
$mName=$_POST['mname'];
$lName=$_POST['lname'];
$add=$_POST['add'];
$mno=$_POST['mobno'];
$lno=$_POST['llineno'];
$wno=$_POST['workno'];
$birthday=$_POST['birthday'];
$gender=$_POST['gender'];

$sql="select * from `users` where `email`='$email'";
$result=  mysql_query($sql);

if(mysql_num_rows ($result )!=0)
{
	echo "failed";
        exit();
}
else{
    $sql="INSERT INTO `users`(`email`, `password`, `fname`, `mname`, `lname`, `add`, `fno`, `mno`, `lno`, `birthday`, `gender`) VALUES ('$email','$pass','$fName','$mName','$lName','$add','$mno','$lno','$wno','$birthday','$gender')";
    $result=  mysql_query($sql);
    if(!$result){
        echo 'Failed';
        exit();
    }
    echo $result;
    header("location: index.php");
}
?>
