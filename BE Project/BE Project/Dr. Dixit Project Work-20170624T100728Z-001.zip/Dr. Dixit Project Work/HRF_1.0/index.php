<?php
include "menu_bar.php";
include "head.php";
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <title>Homeopathy Remedy Finder</title>
        <style>
            
        </style>
    </head>
    <body style="background-color:#f7f5ee">
        <form>
            <div class="home_header"><p class="header_text">Homeopathy Remedy Finder<p></div>
            
            <div class="register">
                <label style="font-family: cursive; float: left; margin-left: 10px; font-size: 40px;">Register with the clinic</label>
                <br>
                <div style="margin-top: 60px; margin-left: 20px;">
                    <div style="width: 100%; margin-bottom: -20px;">
                        <input type="text" style="width: 31%" class="textbox" id="fname" placeholder="First Name"/>
                        <input type="text" style="width: 31%" class="textbox" id="mname" placeholder="Middle Name"/>
                        <input type="text" style="width: 31%" class="textbox" id="lname" placeholder="Last Name"/>
                    </div>
                    <br>
                    <textarea class="textbox" id="address" placeholder="Address" rows="2" style="height: 65px;"></textarea>
                    <div style="width: 100%; margin-bottom: -20px;">
                        <input type="tel" style="width: 31%" class="textbox" id="mno" placeholder="Mobile No." onkeyup="validateNo();"/>
                        <input type="tel" style="width: 31%" class="textbox" id="lno" placeholder="Home No." onkeyup="validateNo();"/>
                        <input type="tel" style="width: 31%" class="textbox" id="wno" placeholder="Work No." onkeyup="validateNo();"/>
                    </div>
                    <!--<br>-->
                    <label id="invalid_no"> Please Enter Valid Number</label><br>
                    <input type="email" class="textbox" id="s_email" placeholder="E-mail" onkeyup="validateEmail();"/>
                        <label id="invalid_email"> Please Enter Valid email</label><br>
                    <input type="password" id="s_pass" class="textbox" placeholder="Password" onkeyup="validatePass();"/>
                        <label id="too_short_pass"> short</label><br>
                    <input type="password" class="textbox" id="c_pass" placeholder="Confirm Password" onkeyup="confirmPass();"/>
                        <label id="incorrect_pass"> incorrect password</label><br>
                        <div style="width: 100%; margin-bottom: -12px">
                            <b>Birthday:</b><input type="date" class="textbox" id="bday" style="width: 30%;"/>
                            <b>Gender:</b><select id="gen"><option value="male">Male</option><option value="female">Female</option></select>
<!--                            <b>Age-Years</b><input type="number" min="0" max="120" class="textbox" id="age_years" style="width: 10%;"/>
                            <b>Months</b><input type="number" min="1" max="12" class="textbox" id="age_months" style="width: 10%;"/>-->
                        </div>
                        
                    <br>
                    <input type="button" value="Submit" id="ok"/>
                </div>
                
                <script>$('#too_short_pass').hide();</script>
                <script>$('#invalid_email').hide();</script>
                <script>$('#incorrect_pass').hide();</script>
                <script>$('#invalid_no').hide();</script>
            </div>
        </form>
        
        <script>
            function validatePass() {
                var x = document.getElementById("s_pass").value;
                if (x.length < 10) {
                    $('#too_short_pass').show();
                }
                else {
                    $('#too_short_pass').hide();
                }
            }
            
            function confirmPass() {
                var x = document.getElementById("s_pass").value;
                var y = document.getElementById("c_pass").value;
                if (x!=y) {
                    $('#incorrect_pass').show();
                }
                else {
                    $('#incorrect_pass').hide();
                }
            }
            
            function validateEmail() {
                var x = document.getElementById("s_email").value;
                var atpos = x.indexOf("@");
                var dotpos = x.lastIndexOf(".");
                if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
                    $('#invalid_email').show();
                }
                else {
                    $('#invalid_email').hide();
                }
            }
            
            function confirmNo() {
           
            }
            
            jQuery(function($) {

                $('#ok').click(function() {
                    var fName=$('#fname');
                    var mName=$('#mname');
                    var lName=$('#lname');
                    var add=$('#address');
                    var mobNo=$('#mno');
                    var lLineNo=$('#lno');
                    var workNo=$('#wno');
                    var emailID = $('#s_email');
                    var password = $('#s_pass');
                    var birthday=$('#bday');
                    var gender=$('#gen');
                
                    if ($('#invalid_email').is(':visible') || $('#too_short_pass').is(':visible') || $('#incorrect_pass').is(':visible')) {
                        alert("Please enter valid email id and password to proceed.");
                        return;
                    }
                    jQuery.ajax({
                        url: 'SignUp.php',
                        type: 'post',
                        data: 'emailID=' + emailID.val() + '&password=' + password.val() + '&fname=' + fName.val() + '&mname=' + mName.val() + '&lname=' + lName.val() + '&add=' + add.val() + '&mobno=' + mobNo.val() + '&llineno=' + lLineNo.val() + '&workno=' + workNo.val() + '&birthday=' + birthday.val() + '&gender=' + gender.val(),
                        success: function(results) {
                            if (results === "success")
                            {
                                alert("registered successfully!");
                            }
                            else
                                alert(""+fName.val());
                        }
                    });
                });
            });
        </script>
    </body>
</html>
