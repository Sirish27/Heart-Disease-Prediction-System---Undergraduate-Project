
<!DOCTYPE html>

<html dir="ltr" lang="en-US">
<head>

    <meta charset="utf-8">

    
    <title>Home</title>

    
    <meta name="viewport" content="initial-scale = 1.0, maximum-scale = 1.0, user-scalable = no, width = device-width">


    
    <link rel="stylesheet" href="style.css" media="screen">

    <link rel="stylesheet" href="style.responsive.css" media="all">




    <script src="jquery.js"></script>

    <script src="script.js"></script>

    <script src="script.responsive.js"></script>






<style>.art-content .art-postcontent-0 .layout-item-0
 { padding-right: 10px;padding-left: 10px;  }
.ie7 .art-post .art-layout-cell
 {border:none !important; padding:0 !important; }
.ie6 .art-post .art-layout-cell
 {border:none !important; padding:0 !important; }
</style>

</head>


<body>


<div id="art-main">

    <div class="art-sheet clearfix">


<nav class="art-nav">

<h1 class="art-headline" align="left" >


    <p>HOMEOPATHY REMEDY FINDER</p>

</h1><br><br>



<ul class="art-hmenu" align="left">
<li><a href="home.php" class="active" align="left">Home</a></li>
<li><a href="contactus.php">Contact Us</a></li>
</ul>

</nav>


<div class="art-layout-wrapper">

<div class="art-content-layout">

<div class="art-content-layout-row">


 <body>
<script type="text/javascript">
function codename() {
 
if(document.getElementById('1').checked==1)
{
document.getElementById('a').disabled=true;
document.getElementById('b').disabled=true;
document.getElementById('c').disabled=true;
document.getElementById('d').disabled=true;
}
}
function codename1(){
 
if(document.getElementById('2').checked==1)
{
document.getElementById('a').disabled=false;
document.getElementById('b').disabled=false;
document.getElementById('c').disabled=true;
document.getElementById('d').disabled=true;
}
}
function codename2(){
if(document.getElementById('3').checked==1)
{
document.getElementById('a').disabled=false;
document.getElementById('b').disabled=false;
document.getElementById('c').disabled=false;
document.getElementById('d').disabled=true;
}
}
function codename3(){
 
if(document.getElementById('4').checked==1)
{
document.getElementById('a').disabled=false;
document.getElementById('b').disabled=false;
document.getElementById('c').disabled=true;
document.getElementById('d').disabled=false;
}
 
}
 
window.onload = function () {
            var ddl = document.getElementById('age').getElementsByTagName("select")[0];
            for (var i = 1; i <= 100; i++) {
                var theOption = new Option;
                theOption.text = i;
                theOption.value = i;
                ddl.options[i] = theOption;
            }
        }
 
function Checkage(val){
 var element=document.getElementById('school');
 if(val>3 && val<21)
   element.style.display='block';
 else  
   element.style.display='none';
 
var element=document.getElementById('marriage');
 if(val>18)
   element.style.display='block';
 else  
   element.style.display='none';
}
 
function Checkreligion(val){
 var element=document.getElementById('religion');
 if(val == 'Other')
   element.style.display='block';
 else  
   element.style.display='none';
}
 
function Checkdiet(val){
 var element=document.getElementById('diet');
 if(val == 'Other')
   element.style.display='block';
 else  
   element.style.display='none';
}
 
 function confirmPass() {
        var pass = document.getElementById("pass").value
        var confPass = document.getElementById("c_pass").value
        if(pass != confPass) {
            alert('Wrong confirm password !');
        }
    }
 
</script>


<div id=background>
<form action="reg.php" method="post" class="rest">
<div id=label>
<fieldset>
<legend>PERSONAL DETAILS</legend>
<label> Name: <input type="text" name="rname" placeholder="Weight"/> </label>
<label> Email: <input type="email" name="email" placeholder="Height"/> </label>
<label> Mobile: <input type="text" name="mob" /> </label>
</fieldset>
<fieldset>
<legend>Personal Information:</legend>
<label> Name:<br> First <input type="text" name="name[]"> </label>
<label> Middle <input type="text" name="name[]"> </label>
<label> Last <input type="text" name="name[]"> </label>
        <div id="age">
<label> Date of birth: <input type="date" name="dob"> </label>
<br><label> Time of birth: <input type="text" name="tob"> </label>
<label> Age: <select id="age" name="age" onchange='Checkage(this.value);'>
         <option value="0"><--Select Age--></option>
         </select> </label>
         <input type="text" name="color" id="color" style='display:none;'/>
    </div>
<label> Place: Town <input type="text" name="place[]"> </label>
<label> State <input type="text" name="place[]"> </label>
<label> Country <input type="text" name="place[]"> </label>
<label> Religion:
<select name="religion[]" onchange='Checkreligion(this.value);'>
<option value="Hinduism">Hinduism</option>
<option value="Islam">Islam</option> 
<option value="Christianity">Christianity</option>
<option value="Sikhism">Sikhism</option>
<option value="Buddhism">  Buddhism</option>
<option value="Jainism">Jainism</option>
<option value="Other" >other</option>
</select>
</label>
<div id="religion" style="display:none;">
Any other religion,specify here
<input type="text" name="religion[]">
</div>
 <br>
<label> Community: <input type="text" name="community"> </label>
<label> Language(Mother Tongue): <input type="text" name="lang"> </label>
<label> Diet: <select name="diet[]" onchange='Checkdiet(this.value);'>
<option value="veg">Vegetarian</option>
<option value="nonveg">Non-Vegetarian</option> 
<option value="eggs">Eggs</option>
<option value="jain">Jain</option>
<option value="Other" >other</option>
</select> </label>
<div id="diet" style="display:none;">
Any other diet,specify here
<input type="text" name="diet[]">
</div><br>
 Sex: <input type="radio" name="sex" value="male">Male
<input type="radio" name="sex" value="female">Female <br>
<div id="marriage" style="display:none;">
<fieldset>
    <legend>Marital Status:</legend>
<input type="radio" name="status" id="1" onchange="codename();" value="single">Single 
<input type="radio" name="status"  id="2" onchange="codename1();" value="married">Married 
<input type="radio" name="status" id="3" onchange="codename2();" value="divorcee">Divorcee 
<input type="radio" name="status" id="4" onchange="codename3();" value="widow">Widow <br>
<label> Date of Marriage: <input type="text" name="dom" id="a"> </label>
<label> Year of Marriage: <input type="text" name="yom" id="b"> </label>
<label> year of Divorce: <input type="text" name="yod" id="c"> </label>
<label> Date of Death: <input type="text" name="dod" id="d"> </label>
</fieldset>
</div>
 

<h3>Enter password</h3>
<label for="pass">Password</label>
   <input type="password" id="pass" class="text" name="your_pass" value=""/>
    <br><label for="c_pass">Confirm Password</label>
    <input type="password" id="c_pass" class="text" name="your_c_pass" value="" onblur="confirmPass()"/>
<br><input type=submit value="Register" style="float: right;">
</fieldset>
</div>
  </form>
</div>




        

     

</div>

</div>
</div>
 
 </div>
 
  </div>
 
 </div>
<footer class="art-footer">

<p><a href="#">Link1</a>&nbsp;</p>

<p>Copyright � 2014. All Rights Reserved.</p>

</footer>


    </div>

    
</div>



</body>
</html>